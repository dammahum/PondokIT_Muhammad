<!DOCTYPE html>
<html>
<head>
	<title>Menghitung Luas Persegi Panjang</title>
</head>
<body>
<?php
function persegi($p, $l){
	echo $p * $l;
}
persegi(20,5);
?>

</body>
</html>