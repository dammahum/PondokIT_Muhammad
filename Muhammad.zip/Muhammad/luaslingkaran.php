<!DOCTYPE html>
<html>
<head>
	<title>Menghitung Luas Lingkaran</title>
</head>
<body>
<?php
function lingkaran($r, $phi=22/7){
	echo $r * $r * $phi;
}
Lingkaran(14)
?>
</body>
</html>