<html>
<head>
<title>PHP</title>
<body>
<?php
   define("situs","www.youtube.com");
   echo situs;  // www.youtube.com
?>

<br>
<hr>
<br>

<?php   
const link="www.bagas31.com";
echo link;
?>
<hr>
</body>
</html>