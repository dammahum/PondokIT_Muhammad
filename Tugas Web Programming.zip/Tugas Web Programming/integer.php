<html>
<head>
<title>Integer</title>
</head>
<body>
<font size="10"><b>Latihan Integer dan Float<b></font>
<hr>
<?php
$x=5986;
var_dump($x);
?>
</body>
</html>
