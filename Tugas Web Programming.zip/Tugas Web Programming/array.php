<html>

<head>
<title>array</title>
</head>

<body>
<?php  
$cars = array(21,22,23,24);
var_dump($cars);
?>  

</body>

</html>