<html>
<head>
<title>PHP</title>
<body>
<h2>String function</h2>
<hr>

<?php
echo strlen("Halo Semua!!!");
?>

<br>
<hr>

<?php
echo strrev("Halo Semua!!!");
?>

<br>
<hr>

<?php
echo str_word_count("Ini Tiga Kata!");
?> 

<br>
<hr>

<?php
echo str_replace("Hello world!", "Hello Buddy!", "Hello world!");
?> 

<br>
<hr>
	
</body>
</html>